const char *gitversion = "";
