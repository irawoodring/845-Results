#!/usr/bin/env bash

for i in {101..200}
do
	./analyze.py $1/$i/HHP_Report.csv $2
done > $3_$1.csv

