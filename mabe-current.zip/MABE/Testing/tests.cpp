#include <gtest/gtest.h>
#include <iostream>

#include "test_graycode.h"

int main(int argc, char* argv[]) {
	testing::InitGoogleTest(&argc, argv);
	return RUN_ALL_TESTS();
}

