const char *gitversion = "7676f5479a279af6cbf65e38e487ea4191aab5e6";
