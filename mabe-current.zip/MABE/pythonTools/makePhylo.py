###################################################################################################
## creates graphviz formatted graph of phylogony
## (I have been using dreampuf.github.io/GraphvizOnline to render my graphs)
##
## uses cat__snapshot_data_*.csv, dog__snapshot_data_*.csv, flea__snapshot_data_*.csv
## and HHP_fleas_*.csv (to determine host types)
##
## Note that the last time will not appear as these organisms have no recored progeny
##               ...so if rmax = 20000 and rsetp = 5000, data will be shown till 15000
###################################################################################################

import argparse
parser = argparse.ArgumentParser()

parser.add_argument('-m','--maxTime', type=int, metavar='UPDATE',  help='last update that you have data for', required=True)
parser.add_argument('-t','--timeStep', type=int, metavar='UPDATES',  help='number of updates between saved files (i.e. snapshot and HHP files)', required=True)
parser.add_argument('-a','--alteredValues', type=str, metavar='LIST', default=None, help='string with values (from .cfg file) to show in values column', required=False)
parser.add_argument('-n','--alteredValuesName', type=str, metavar='LABEL', default='values', help='label for altered values column', required=False)
args = parser.parse_args()

###################################################################################################
###################################################################################################
## make sure ARCHIVIST_DEFAULT-snapshotDataSequence = WORLD_HHP_IO-recordGenomesStep
###################################################################################################
###################################################################################################

rmax = args.maxTime    ## last update that you have data for
rstep = args.timeStep  ## rate at which data was saved


AlteredValues = args.alteredValues          ## string with values line from .cfg file
AlteredValuesName = args.alteredValuesName  ## label for altered values column
#set AlteredValues = None to have no altered values column

###################################################################################################
## do not change below this line
###################################################################################################

def rq(s):
    if s[0] == '"':
        s = s[1:]
    if len(s) > 1 and s[-1] == '"':
        s = s[:-1]
    return s

rmax += rstep

colors = ['gray','black','gray','black','gray','black','gray','black','gray','black','gray','black']
colors = colors * 100
groupNames = ['dog','cat','flea']
output = ''


###################################################################################################
## CREATE RATES SUBGRAPH
###################################################################################################
if AlteredValues != None:
    rawValues = AlteredValues ## values line from .cfg file
    times = []
    values = []

    for X in rawValues.split(','):
        times.append(int(X.split('X')[0]))
        values.append(float(X.split('X')[1]))

    timeCounter = 0
    value = values[0]

    ratesOfT = []
    for t in range(0,rmax-rstep,rstep):
        if timeCounter < (len(times)):
            if times[timeCounter] == t:
                value = values[timeCounter]
                timeCounter+=1
        ratesOfT.append(value)

    output += 'subgraph clusterrates {\n'
    output += 'label = "' + AlteredValuesName + '"\n' ## change label here
    output += 'rF' + ' -> '
    count = 0;
    for r in ratesOfT:
        output += 'r'+str(count) + ' -> '
        count += 1
    output = output[:-4]+' [color=white]\n}\n'

    output += 'rF [label =  " " color = white]\n'
    count = 0;
    for r in ratesOfT:
        output += 'r'+str(count) + ' [label = ' + str(r) + ' shape = square]\n'
        count += 1


###################################################################################################
## CREATE TIME SUBGRAPH
###################################################################################################
output += 'subgraph clustertime {\nlabel=time\n'
output += 'progenitors -> '
for t in range(0,rmax-rstep,rstep):
    output += '"time ' + str(t) + '" -> '
output = output[:-4]+' [color = white]\n}\n'




###################################################################################################
## CREATE CAT, DOG and FLEA SUBGRAPHS
###################################################################################################

prevFleaIDs = []
prevFleaHostTypes = []
fleaIDs = []
fleaHostTypes = []


for groupName in groupNames:
    indexList = []
    pairsList = []
    nextIndexList = []
    nextPairsList = []
    for t in range(0,rmax,rstep):
        print('loading: ' + groupName + '__snapshot_data_' + str(t) + '.csv',flush=True)
        f = open(groupName+'__snapshot_data_'+str(t)+'.csv', 'r')
        fileData = f.readlines()
        f.close()
        columnNames = fileData[0].split(',')
        IDIndex = columnNames.index('ID')
        AncestorsIndex = columnNames.index('snapshotAncestors_LIST')

        if groupName == 'flea':
            prevFleaIDs = fleaIDs
            prevFleaHostTypes = fleaHostTypes
            
            fleas_file = open('HHP_fleas_'+str(t)+'.csv', 'r')
            print('loading: HHP_fleas_'+str(t)+'.csv',flush=True)
            fleasFileDataRaw = fleas_file.readlines()
            fleas_file.close()
            columnNames = fleasFileDataRaw[0].split(',')
            fleasIDIndex = columnNames.index('ID')
            fleasHostTypeIndex = columnNames.index('hostType')
            fleaIDs = []
            fleaHostTypes = []
            for flea_line in fleasFileDataRaw:
                if len(flea_line.split(',')) > 1:
                    fleaIDs.append(flea_line.split(',')[fleasIDIndex])
                    fleaHostTypes.append(flea_line.split(',')[fleasHostTypeIndex])
                
        if t == 0:
            for i in range(1,len(fileData)):
                l = fileData[i].split(',')
                indexList.append(l[IDIndex])
                pairsList.append([l[IDIndex],rq(l[AncestorsIndex])])
            output += 'subgraph cluster'+ groupName + ' {\n'
            output += 'label = ' + groupName + '\n'
        else:
            written = []
            for i in range(1,len(fileData)):
                l = fileData[i].split(',')
                nextIndexList.append(l[IDIndex])
                nextPairsList.append([l[IDIndex],rq(l[AncestorsIndex])])
            for thisPair in nextPairsList:
                if thisPair[1] in indexList:
                    indexList.remove(thisPair[1])
                    found = False
                    for p in pairsList:
                        if p[0] == thisPair[1]:
                            pp = p
                            found = True
                    if found == False:
                        print("error! Could not find ancestor with ID:",thisPair[1],"in group",groupName,"at time",t)
                        break;
                    output += pp[1] + ' -> ' + pp[0] + '\n'
                    
                    if groupName == 'flea':
                        if prevFleaHostTypes[prevFleaIDs.index(pp[0])] == '0':
                            output += pp[0] + ' [color=red style=filled fillcolor=pink]\n'
                        else:
                            output += pp[0] + ' [color=blue style=filled fillcolor=lightblue]\n'
                    else:
                        ccc = colors[int((t-1)/rstep)]
                        #output += pp[0] + ' [color=' + colors[int((t-1)/rstep)] + ']\n'
                        output += pp[0] + ' [color=' + ccc + ']\n'

            indexList = nextIndexList
            pairsList = nextPairsList
            nextIndexList = []
            nextPairsList = []
    output += '}\n'
print('\n\n\n\nOUtPUT... plug this into graphviz\n\n\n')     
print(output)  