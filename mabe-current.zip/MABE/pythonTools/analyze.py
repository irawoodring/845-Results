#!/usr/bin/env python3

import csv
import numpy as np
import matplotlib.pyplot as plt
import sys

with open(sys.argv[1], 'r') as f:
    reader = csv.reader(f, delimiter=',')
    header = next(reader)
    data = np.array(list(reader)).astype(float)

col = int(sys.argv[2])
#print("Reading column " + str(col) + ": " + header[col])
#print("First two values: " + str(data[0][col]) + ", and " + str(data[1][col]))
print(str(np.mean(data[:,col])) + "," + str(np.std(data[:,col])))
